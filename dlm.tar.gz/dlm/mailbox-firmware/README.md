# mailbox-firmware/

This directory is a placeholder for the embedded firmware that would run on
the physical Magic Mailbox device. The hardware itself is out of scope for
this course project — we cannot ship a soldering iron with the repo — but the
*interface* it presents is fully implemented in `agents/mailbox_agent.js`.

## What the real device would do

1. Hold a single ECDSA key pair inside a secure element (e.g. ATECC608 or an
   nRF52840 with TrustZone). The private key never leaves the SE; the
   firmware only ever calls the SE's `sign` primitive.

2. Read package sensors:
   * weight sensor (load cell on the floor of the box)
   * door open/close (Hall-effect or contact switch)
   * optional camera frame hash (for after-the-fact audit, not signed)

3. When the package is dropped:
   * Bundle `{weight_grams, dropped_at_unix_ts, door_open_duration_ms}`.
   * Concatenate with the dropoff `code` and `nonce` (entered by the courier
     on a small keypad / QR scan).
   * Sign `keccak256(code || deliveryId || nonce)` with the SE key.
   * Submit the resulting `confirmDelivery` transaction via the device's
     LTE-M / WiFi modem.

4. Rate-limit: at most one confirmation per `deliveryId`, and never more than
   N confirmations per hour globally (defence against a compromised but
   live-key adversary who tries to drain everything before the buyer
   notices).

## How `agents/mailbox_agent.js` maps onto this

The off-chain agent we ship simulates exactly the same flow, using a JSON
sensor file in place of real hardware:

| firmware concept | `mailbox_agent.js` equivalent |
|---|---|
| Secure-element key | `MAILBOX_KEY` env var (treated as if write-only; never logged) |
| Sensor read | `--sensors path/to/sensors.json` |
| Sign + submit | `confirmDelivery` call via ethers.js |
| Rate-limit | in-memory map keyed by `deliveryId`, plus a global QPS cap |

The on-chain logic (`DeliveryVault.confirmDelivery`) does not care which side
of this boundary the signature came from. That is the whole point — the
contract trusts the *key*, not the *device*, so swapping a simulated agent for
a real device requires no contract changes.

## Firmware update policy (not implemented)

Per §4 of the threat model, real firmware updates would require signed images
from a known root (e.g. a dual-signature scheme: the manufacturer key plus the
pool operator's key). Bricked / out-of-date mailboxes would refuse to sign.
This is hardware policy and is documented here for completeness.
